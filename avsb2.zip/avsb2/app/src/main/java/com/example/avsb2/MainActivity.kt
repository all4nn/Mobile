package com.example.avsb2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var web_view: WebView = findViewById(R.id.webview)

    // Configurar as configurações da WebView
        val webSettings: WebSettings = web_view.settings
        webSettings.javaScriptEnabled = true
    // Carregar um site externo (por exemplo, o site da up)
        web_view.loadUrl("https://clickanitta.com/")

    }
}